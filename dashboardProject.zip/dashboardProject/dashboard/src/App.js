import './App.css';
import Dashboard from './component/Dashboard';

function App() {
  return (
    <div className="App" >
     <Dashboard/>
    </div>
  );
}

export default App;
