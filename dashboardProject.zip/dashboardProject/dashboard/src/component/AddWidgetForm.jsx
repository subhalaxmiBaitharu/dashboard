import React, { useEffect, useState } from "react";
import initialData from "./data.json";
import { Box, Drawer, Tab } from "@mui/material";
import cross from "../images/x-button.png";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";

const AddWidgetForm = ({
  onAddWidget,
  categories,
  anchorOpen,
  setAnchorOpen,
}) => {
  const [allCategories] = useState(initialData.categories);
  const [categoryId, setCategoryId] = useState(categories[0]?.id || "");
  const [selectedWidgets, setSelectedWidgets] = useState([]);
  useEffect(() => {
    if (categoryId) {
      const displayedWidgets =
        categories.find((category) => category.id === categoryId)?.widgets ||
        [];
      setSelectedWidgets(displayedWidgets);
    }
  }, [categoryId, allCategories, categories]);

  const handleCheckboxChange = (widget) => {
    console.log(widget, categoryId, categories);
    setSelectedWidgets((prevSelected) => {
      if (prevSelected.some((selected) => selected.id === widget.id)) {
        return prevSelected.filter((selected) => selected.id !== widget.id);
      } else {
        return [...prevSelected, widget];
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddWidget(categoryId, selectedWidgets);
    // setSelectedWidgets([]);
    setAnchorOpen(false);
  };

  const [value, setValue] = React.useState("1");

  const handleChange = (event, newValue) => {
    setValue(newValue);
    console.log("value", event.target.value);
    setCategoryId(Number(value));
  };
  useEffect(()=>{
    setCategoryId(Number(value));
  },[value])
  function closeFunction(){
    setAnchorOpen(false)
  }

  return (
    <Drawer
      sx={{
        "& .MuiPaper-root": {
          width: "25rem",
        },
      }}
      anchor={"right"}
      open={anchorOpen}
      onClose={() => setAnchorOpen(!anchorOpen)}
    >
      <nav
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          height: "3rem",
          background: "rgba(21,21,125,255)",
        }}
      >
        <p style={{ color: "#fff", marginLeft: "1rem" }}>Add Widget</p>
        <img onClick={closeFunction} style={{ width: "1rem", marginRight: "1rem" ,cursor:"pointer"}}  alt="" src={cross} />
      </nav>
      <form
        onSubmit={handleSubmit}
        className="add-widget-form"
        style={{ display: "flex", flexDirection: "column", gap: "1rem" }}
      >
        <Box sx={{ width: "100%", typography: "body1" }}>
          <TabContext value={value}>
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
              <TabList
              sx={{fontSize:"1rem"}}
                onChange={handleChange}
                aria-label="lab API tabs example"
              >
                <Tab label="CSPM" value="1" />
                <Tab label="CWPP" value="2" />
                <Tab label="RS" value="3" />
                <Tab label="Image" value="4" />
                <Tab label="Ticket" value="5" />
              </TabList>
            </Box>
            <TabPanel value={value}>
              <div>
                {(
                  allCategories.find((category) => category.id === categoryId)
                    ?.widgets || []
                ).map((widget) => (
                  <div
                    key={widget.id}
                    style={{ display: "flex", alignItems: "center" ,border:"2px solid #e3e7ef",borderRadius:"5px",padding:"0.2rem 0 0.2rem 1rem",marginBottom:"0.5rem"}}
                  >
                    <input
                      type="checkbox"
                      id={`widget-${widget.id}`}
                      checked={selectedWidgets.some(
                        (selected) => selected.id === widget.id
                      )}
                      onChange={() => handleCheckboxChange(widget)}
                    />
                    <label
                      htmlFor={`widget-${widget.id}`}
                      style={{ marginLeft: "0.5rem" }}
                    >
                      {widget.name}
                    </label>
                  </div>
                ))}
              </div>
            </TabPanel>
          </TabContext>
        </Box>
        <div style={{position:"absolute",bottom:"0.5rem",right:"1rem"}}>
          <button style={{cursor:"pointer",padding:"0.3rem 1rem 0.3rem 1rem",backgroundColor:"#fff",color:"rgba(21,21,125,255)",borderRadius:"5px"}}>Cancel</button>
          <button type="submit" style={{cursor:"pointer",padding:"0.3rem 1rem 0.3rem 1rem",marginLeft:'0.5rem',backgroundColor:"rgba(21,21,125,255)",color:"#fff",borderRadius:"5px"}}>Confirm</button>
        </div>
      </form>
    </Drawer>
  );
};

export default AddWidgetForm;
