import React, { useState, useEffect } from "react";
import Category from "./Category";
import AddWidgetForm from "./AddWidgetForm";
import initialData from "./data.json";
import plus from '../images/add.png'
import Refresh from '../images/refresh.png'
import Dots from '../images/dots.png'
import Last from '../images/last.png'

const Dashboard = () => {
  const [categories, setCategories] = useState(
    initialData.categories.map(category => ({ ...category, widgets: [] }))
  );
  const [anchorOpen, setAnchorOpen] = useState(false)

  useEffect(() => {
    // Load saved state from localStorage
    const savedCategories = JSON.parse(localStorage.getItem("categories")) || [];
    if (savedCategories.length) {
      setCategories(savedCategories);
    }
  }, []);

  const addWidget = (categoryId, selectedWidgets) => {
    const newCategoryData = categories.map((category) =>
      category.id === categoryId
        ? { ...category, widgets: [...selectedWidgets] }
        : category
    );
    setCategories(newCategoryData);
    localStorage.setItem("categories", JSON.stringify(newCategoryData));
  };

  // const removeWidget = (categoryId, widgetId) => {
  //   setCategories((prevCategories) =>
  //     prevCategories.map((category) =>
  //       category.id === categoryId
  //         ? {
  //           ...category,
  //           widgets: category.widgets.filter((w) => w.id !== widgetId),
  //         }
  //         : category
  //     )
  //   );
  // };

  const removeWidget = (categoryId, widgetId) => {
    const newCategoryData = categories.map((category) =>
      category.id === categoryId
        ? {
          ...category,
          widgets: category.widgets.filter((w) => w.id !== widgetId),
        }
        : category
    )
    setCategories(newCategoryData)
    localStorage.setItem("categories", JSON.stringify(newCategoryData));
  };

  return (
    <div style={{ backgroundColor: "#f2f5fa", padding: "2rem 3rem" }}>
      <nav
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <p style={{ fontWeight: "bolder",fontSize:"1.3rem" }}>CNAPP Dashboard</p>
        <div style={{display:"flex",width:"23%",justifyContent:"space-between"}}>
        <button style={{display:'flex',alignItems:"center",cursor:"pointer", background:"#fff",border:"2px solid gray",borderRadius:"5px",height:"2rem"}} onClick={() => setAnchorOpen(true)}>Add Widget<img style={{width:"1rem",marginLeft:"0.2rem"}} src={plus}/></button>
        <div style={{display:'flex',alignItems:"center",cursor:"pointer",justifyContent:"center",background:"#fff",border:"2px solid gray",width:"1.8rem",height:"1.8rem",borderRadius:"5px"}}>
        <img style={{width:"1rem"}} src={Refresh}/>
        </div>
        <div style={{display:'flex',alignItems:"center",cursor:"pointer",justifyContent:"center",background:"#fff",border:"2px solid gray",width:"1.8rem",height:"1.8rem",borderRadius:"5px"}}>
        <img style={{width:"1rem"}} src={Dots}/>
        </div>
        <div style={{border:"2px solid #050C9C",cursor:"pointer",height:"1.9rem",borderRadius:"5px",background:"#fff"}}>
        <img style={{width:"8rem",paddingInline:"0.1rem"}} src={Last}/>
        </div>
        </div>
        <AddWidgetForm
          onAddWidget={addWidget}
          categories={categories}
          selectedWidgets={categories.flatMap(category => category.widgets)}
          anchorOpen={anchorOpen}
          setAnchorOpen={setAnchorOpen}
        />
      </nav>
      <div style={{ marginTop: "1rem" }}>
        {categories.map((category) => (
          <Category
            key={category.id}
            category={category}
            onRemoveWidget={removeWidget}
            setAnchorOpen={setAnchorOpen}
          />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
