import React, { useState } from 'react';
import DonutChart from './DonutChart';
import BarChart from './BarChart';
import LinearBarChart from'./LinearBarChart';
import cross from '../images/x-button.png'
import '../App.css'

// const data = {
//   labels: ['Vulnerabilities'], // Single label since it's a single bar
//   datasets: [
//     {
//       label: 'Critical',
//       data: [9], // Number of critical vulnerabilities
//       backgroundColor: 'rgba(255, 0, 0, 0.8)', // Red color for critical
//       barThickness: 30,
//     },
//     {
//       label: 'High',
//       data: [150], // Number of high vulnerabilities
//       backgroundColor: 'rgba(255, 69, 0, 0.8)', // Orange color for high
//       barThickness: 30,
//     },
//     {
//       label: 'Medium',
//       data: [500], // Number of medium vulnerabilities
//       backgroundColor: 'rgba(255, 165, 0, 0.8)', // Yellow-orange color for medium
//       barThickness: 30,
//     },
//     {
//       label: 'Low',
//       data: [811], // Number of low vulnerabilities
//       backgroundColor: 'rgba(255, 205, 86, 0.8)', // Yellow color for low
//       barThickness: 30,
//     },
//   ],
// };

const data = {
  labels: ['Vulnerabilities'], // Single label for a single horizontal bar
  datasets: [
    {
      label: 'Critical',
      data: [300], // Number of critical vulnerabilities
      backgroundColor: 'rgba(255, 0, 0, 0.8)', // Red color for critical
      stack: 'Stack 0',
      barThickness: 20,
      borderRadius: 20 
    },
    {
      label: 'High',
      data: [150], // Number of high vulnerabilities
      backgroundColor: 'rgba(255, 69, 0, 0.8)', // Orange color for high
      stack: 'Stack 0',
      barThickness: 20,
    },
    {
      label: 'Medium',
      data: [500], // Number of medium vulnerabilities
      backgroundColor: 'rgba(255, 165, 0, 0.8)', // Yellow-orange color for medium
      stack: 'Stack 0',
      barThickness: 20,
    },
    {
      label: 'Low',
      data: [811], // Number of low vulnerabilities
      backgroundColor: 'rgba(255, 205, 86, 0.8)', // Yellow color for low
      stack: 'Stack 0',
      barThickness: 20,
      borderRadius: 10 
    },
  ],
};

// Chart options
const LinearOptions = {
  layout: {
    padding: 0 ,
    margin:0// Adjust padding around the chart
  },
  indexAxis: 'y', // Make the chart horizontal
  scales: {
    x: {
      stacked: true, // Stack the segments on the same horizontal line
      display: false, // Completely hide the x-axis
    },
    y: {
      stacked: true, // Stack the segments on the same horizontal line
      display: false, // Completely hide the y-axis
    },
  },
  plugins: {
    legend: {
      position: 'bottom', 
      labels: {
        boxWidth: 12, // Adjust the width of the legend box
        padding: 10, // Add some padding between legend items
        font: {
          size: 12, // Adjust the font size
        },
      }
    },
    tooltip: {
      callbacks: {
        label: function(tooltipItem) {
          return `${tooltipItem.dataset.label}: ${tooltipItem.raw}`;
          },
        },
      },
    },
  };

const bardata = {
  labels: ['January', 'February', 'March', 'April', 'May', 'June'],
  datasets: [
    {
      label: 'Sales 2024 (in USD)',
      data: [12000, 19000, 3000, 5000, 20000, 30000],
      backgroundColor: 'rgba(75, 192, 192, 0.2)',
      borderColor: 'rgba(75, 192, 192, 1)',
      borderWidth: 1,
    },
    {
      label: 'Sales 2023 (in USD)',
      data: [15000, 12000, 8000, 13000, 15000, 17000],
      backgroundColor: 'rgba(153, 102, 255, 0.2)',
      borderColor: 'rgba(153, 102, 255, 1)',
      borderWidth: 1,
    },
  ],
};

const horizontalOption = {
  indexAxis: 'y', // This makes the bar chart horizontal
  scales: {
    x: {
      beginAtZero: true,
    },
  },
  responsive: true,
  plugins: {
    legend: {
      position: 'top',
      labels: {
        boxWidth: 12, // Adjust the width of the legend box
        padding: 10, // Add some padding between legend items
        font: {
          size: 12, // Adjust the font size
        }}
    },
    title: {
      display: true,
    },
  },
};
const barOptions = {
  scales: {
    y: {
      beginAtZero: true,
    },
  },
  plugins: {
    legend: {
      display: true,
      position: 'top',
      labels: {
        boxWidth: 12, // Adjust the width of the legend box
        padding: 10, // Add some padding between legend items
        font: {
          size: 12, // Adjust the font size
        }}
    },
    tooltip: {
      enabled: true,
    },
  },
};

const options = {
  responsive: true,
  cutout: '60%',
  layout: {
    padding: {
      left: 20,
      right: 0,
      top: 0,
      bottom: 100,
    },
  },
  plugins: {
    legend: {
      position: 'right',
      labels: {
        boxWidth: 12, // Adjust the width of the legend box
        padding: 10, // Add some padding between legend items
        font: {
          size: 12, // Adjust the font size
        }}
    },
    title: {
      display: true,
    },
  },

};
const Widget = ({ dataSet, onRemove,mainKey}) =>  {

return (
 (mainKey === 1)?
 <div style={{display:"flex",flexWrap:"wrap"}}>
    <div className="widget" style={{display:"flex",flexDirection:"column",borderRadius:"0.5rem", width:"21.5rem",height:"14rem",margin:"1rem 1rem 1rem 0rem",justifyContent:"space-between", backgroundColor:"#fff"}}>
    <div style={{display:"flex",justifyContent:"space-between",alignContent:"center",margin:"0.5rem 0.5rem 0 1rem"}}>
      <p style={{fontWeight:"bolder"}}>{dataSet.name}</p>
      <img onClick={onRemove} style={{width:"1rem",cursor:"pointer",marginRight:"0.5rem"}} src={cross}/>
    </div>
    <p style={{marginTop:"1rem",marginLeft:"1rem"}}>{dataSet.text}</p>
    <div style={{height:"15rem"}}>
    <DonutChart data={dataSet.graph} options={options} />
    </div>
  </div>
  </div>
      
  :
(mainKey === 2 )?
<div style={{display:"flex",flexWrap:"wrap"}}>
<div className="widget" style={{display:"flex",flexDirection:"column",borderRadius:"0.5rem", width:"21.5rem",height:"14rem",margin:"1rem 1rem 1rem 0rem",justifyContent:"space-between", backgroundColor:"#fff"}}>
    <div style={{display:"flex",justifyContent:"space-between",alignContent:"center",margin:"0.5rem 0.5rem 0 1rem"}}>
      <p style={{fontWeight:"bolder"}}>{dataSet.name}</p>
      <img onClick={onRemove} style={{width:"1rem",cursor:"pointer",marginRight:"0.5rem"}} src={cross}/>
    </div>
<p style={{marginLeft:"1rem"}}>{dataSet.text}</p>
<div style={{marginInline:"1rem"}}>
<BarChart data={bardata} options={barOptions} />
</div>
</div>
</div>
:
<div style={{display:"flex",flexWrap:"wrap"}}>
<div className="widget" style={{display:"flex",flexDirection:"column",borderRadius:"0.5rem", width:"21.5rem",height:"14rem",margin:"1rem 1rem 1rem 0rem",justifyContent:"space-between", backgroundColor:"#fff"}}>
    <div style={{display:"flex",justifyContent:"space-between",alignContent:"center",margin:"0.5rem 0.5rem 0 1rem"}}>
      <p style={{fontWeight:"bolder"}}>{dataSet.name}</p>
      <img onClick={onRemove} style={{width:"1rem",cursor:"pointer",marginRight:"0.5rem"}} src={cross}/>
    </div>
    <p style={{marginLeft:"1rem"}}>{dataSet.text}</p>
<div style={{marginInline:"1rem",paddingBottom:"1rem"}}>
<LinearBarChart data={data} options={LinearOptions} />
</div>

</div>
</div>

)};

export default Widget;
