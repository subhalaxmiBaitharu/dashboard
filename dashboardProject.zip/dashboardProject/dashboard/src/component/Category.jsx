import React from 'react';
import Widget from './Widget';
import plus from '../images/add.png'

const Category = ({ category, onRemoveWidget, setAnchorOpen }) => {
  var c=0;
return (
  <div className="category" style={{}}>
    <h3>{category.name}</h3>
    <div className="widgets" style={{ display: "flex" ,justifyContent:"flex-start",alignItems:"center"}}>
      {category?.widgets?.map(widget => { 
        c++;
        return(
        <Widget
          mainKey={category.id}
          key={widget.id}
          dataSet={widget}
          onRemove={() => onRemoveWidget(category.id, widget.id)}
        />
      )})}
      {c!=4 &&<div className='widget' style={{display:"flex",justifyContent:"center",alignItems:"center",borderRadius:"0.5rem", width:"21.5rem",height:"14rem",backgroundColor:"white",marginBlock:"1rem"}}>
        <button style={{display:'flex',alignItems:"center",cursor:"pointer", background:"#fff",border:"2px solid gray",borderRadius:"5px",height:"1.8rem",backgroundColor:"#f2f5fa"}} onClick={() => setAnchorOpen(true)}><img style={{width:"1rem",marginRight:"0.4em"}} src={plus}/>Add Widget</button>
      </div>}
    </div>
  </div>
)};

export default Category;
